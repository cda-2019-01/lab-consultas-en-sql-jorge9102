## 
## Escriba una consulta que retorne los primeros cinco
## registros de la tabla tbl1 ordenados por fecha
## 


SELECT * FROM tbl1 ORDER BY c14 LIMIT 5;