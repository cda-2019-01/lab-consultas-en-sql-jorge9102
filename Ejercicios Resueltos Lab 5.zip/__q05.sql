## 
## Escriba una consulta que retorne todos los campos de 
## la tabla tbl0 para los que el campo c02 es igual a 100
## o igual a 600
## 

SELECT * FROM tbl0 WHERE c02 = 100 or C02 = 600;