## 
## Escriba una consulta que retorne todos los 
## campos de los registros de la tabla tbl0 
## con la columna ## c02 mayor o igual a 300.
##


SELECT * FROM tbl0 WHERE C02 >= 300;