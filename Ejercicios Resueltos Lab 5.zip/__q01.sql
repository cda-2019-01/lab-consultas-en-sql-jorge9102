## 
## Escriba una consulta que devuelva la suma del campo c12
## de la tabla tbl1
## 

SELECT SUM(c12) FROM tbl1;