## 
## Escriba una consulta que retorne todos los campos de 
## la tabla tbl1 ordenada por fecha (c14) para los 
## registros con K0 igual a A
## 


SELECT * FROM tbl1 WHERE K0 = 'A' ORDER BY C14;