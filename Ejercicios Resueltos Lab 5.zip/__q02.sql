## 
## Escriba una consulta que retorne la cantidad de registros
## de la tabla tbl1
## 


SELECT COUNT(*) FROM tbl1;